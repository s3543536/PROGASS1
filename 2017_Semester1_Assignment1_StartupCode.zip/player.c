#include "player.h"

void initialisePlayer(Player * player, Position * position, Direction direction)
{
    /* TODO */
}

void turnDirection(Player * player, TurnDirection turnDirection)
{
    /* TODO */
}

Position getNextForwardPosition(const Player * player)
{
    /* TODO */
    Position position;

    return position;
}

void updatePosition(Player * player, Position position)
{
    /* TODO */
}

void displayDirection(Direction direction)
{
    /* TODO */
}
