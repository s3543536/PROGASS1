#include "carboard.h"

int main()
{
    /* TODO */
    printf("Good bye! \n\n");

    return EXIT_SUCCESS;
}

void showStudentInformation()
{
    /* TODO */
}
